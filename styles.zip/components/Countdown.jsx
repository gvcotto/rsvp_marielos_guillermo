// components/Countdown.jsx
import { useEffect, useState } from "react";

export default function Countdown({ targetISO }) {
  const [t, setT] = useState({ d:0, h:0, m:0, s:0 });

  useEffect(() => {
    const target = new Date(targetISO).getTime();
    const id = setInterval(() => {
      const now = Date.now();
      const diff = Math.max(0, target - now);
      const d = Math.floor(diff / (1000*60*60*24));
      const h = Math.floor((diff/(1000*60*60)) % 24);
      const m = Math.floor((diff/(1000*60)) % 60);
      const s = Math.floor((diff/1000) % 60);
      setT({ d, h, m, s });
    }, 1000);
    return () => clearInterval(id);
  }, [targetISO]);

  return (
    <div className="countdown-wrap">
      <Box n={t.d} label="Días" />
      <Box n={t.h} label="Horas" />
      <Box n={t.m} label="Min" />
      <Box n={t.s} label="Seg" />
    </div>
  );
}

function Box({ n, label }) {
  return (
    <div className="cd-box">
      <div className="cd-num h-font">{String(n).padStart(2,"0")}</div>
      <div className="cd-lbl">{label}</div>
    </div>
  );
}
