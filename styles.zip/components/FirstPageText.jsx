// components/FirstPageText.jsx
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/router";

export default function FirstPageText() {
  const router = useRouter();
  const { n, p, s } = router.query;

  const [displayName, setDisplayName] = useState(
    n ? decodeURIComponent(n) : ""
  );
  const [seats, setSeats] = useState(Number(s || 1));
  const [leaving, setLeaving] = useState(false); // <-- nuevo (fade de salida)

  useEffect(() => {
    async function load() {
      try {
        if (!p) return;
        const r = await fetch(`/api/party?token=${encodeURIComponent(p)}`);
        const j = await r.json();
        if (j?.ok && j.party) {
          const m = Array.isArray(j.party.members)
            ? j.party.members.filter(Boolean).length
            : 1;
          setSeats(m > 0 ? m : 1);

          const sheetName = j.party.displayName?.trim();
          const urlName = n ? decodeURIComponent(n).trim() : null;
          setDisplayName(urlName || sheetName || "Invitado/a");
        }
      } catch {}
    }
    load();
  }, [p, n]);

  const goRSVP = () => {
    // Transición suave: mostramos overlay y navegamos al terminar
    setLeaving(true);
    const q = new URLSearchParams();
    if (p) q.set("p", p);
    if (n) q.set("n", n);
    setTimeout(() => {
      router.push(`/detalles?${q.toString()}`);
    }, 420); // debe coincidir con la duración del CSS
  };

  const seatsFragment = useMemo(() => {
    return (
      <span
        className="seat-num seat-num-only"
        aria-label={`Lugares reservados: ${seats}`}
      >
        {seats}
      </span>
    );
  }, [seats]);

  return (
    <main className="cover-wrap">
      {/* Cabecera */}
      <header className="hero-head">
        <div className="h-font hero-sub hero-rose">NUESTRA BODA</div>
        <h1 className="h-font hero-names hero-rose">Marielos &amp; Guillermo</h1>
      </header>

      {/* Imagen central (sobre) */}
      <section className="cover-center">
        <img
          src="/canva/centerpiece.png"
          alt="Abrir invitación"
          className="centerpiece small"
          onClick={goRSVP}
        />
      </section>

      {/* Tu invitación: {displayName} */}
      <div className="cover-guest">
        <span className="h-font hero-sub hero-rose">TU INVITACIÓN:&nbsp;</span>
        <span className="h-font hero-rose guest-name-normal">
          {displayName?.trim() || "Invitado/a"}
        </span>
      </div>

      {/* Caja “Hemos reservado …” (sin guiones) */}
      <section className="cover-reserve">
        <div className="reserve-card-canvas rose">
          <div className="reserve-inner rose">
            <span className="h-font">Hemos reservado</span>
            {seatsFragment}
            <span className="h-font">lugar(es) en tu honor</span>
          </div>
        </div>
      </section>

      {/* Overlay de salida para el fade */}
      <div className={`page-fader ${leaving ? "show" : ""}`} />
    </main>
  );
}
