// components/HeroPhoto.jsx
export default function HeroPhoto({
  title = "Marielos & Guillermo",
  subtitle = "¡Nos casamos!",
  src = "/photos/hero.jpg",
}) {
  return (
    <section className="hero-photo">
      <img src={src} alt={title} className="hero-photo__img" />
      <div className="hero-photo__overlay" />
      <div className="hero-photo__text">
        <h1 className="h-font hero-rose hero-photo__title">{title}</h1>
        <div className="h-font hero-sub hero-rose hero-photo__subtitle">
          {subtitle}
        </div>
      </div>
      <a href="#rsvp" className="hero-photo__chevron" aria-label="Ir a RSVP">
        <span />
      </a>
    </section>
  );
}
