// components/RSVPInline.jsx
import { useEffect, useState } from "react";

export default function RSVPInline({ token, fallbackName, onConfirmed = () => {} }) {
  const [members, setMembers] = useState([]);
  const [answers, setAnswers] = useState({});   // { "Nombre": "yes" | "no" }
  const [note, setNote] = useState("");
  const [sending, setSending] = useState(false);
  const [ok, setOk] = useState(false);

  // Carga miembros por token
  useEffect(() => {
    async function load() {
      if (!token) return;
      const r = await fetch(`/api/party?token=${encodeURIComponent(token)}`);
      const j = await r.json();
      if (j?.ok && Array.isArray(j.party?.members)) {
        const arr = j.party.members.filter(Boolean);
        setMembers(arr);
        // preset vacío
        const preset = {}; arr.forEach(n => preset[n] = answers[n] || "");
        setAnswers(preset);
      }
    }
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  function pick(name, val) {
    setAnswers(a => ({ ...a, [name]: val }));
  }

  async function submit() {
    setSending(true);
    try {
      // estructura simple por persona
      const rows = members.map(n => ({
        token, name:n, answer: answers[n] || "", note,
        receivedAt: new Date().toISOString()
      }));
      // Enviamos cada fila (o 1 payload único; depende de tu Apps Script)
      await fetch("/api/rsvp", {
        method:"POST",
        headers:{ "Content-Type":"application/json" },
        body: JSON.stringify({ rows })
      });
      setOk(true);
      onConfirmed();
    } catch (_) {}
    setSending(false);
  }

  if (ok) {
    return (
      <div className="card" style={{textAlign:"center"}}>
        <div className="sec-title">¡Gracias por confirmar!</div>
        <div className="sec-text">Tu registro fue recibido correctamente.</div>
      </div>
    );
  }

  return (
    <div className="rsvp-card">
      <div className="sec-text" style={{marginBottom:10}}>
        Grupo: <b>{fallbackName || "Invitado/a"}</b>
      </div>

      <div className="rsvp-members">
        {members.map(n => (
          <div key={n} className="rsvp-row">
            <div className="rsvp-name">{n}</div>
            <div className="rsvp-actions">
              <button
                className={`btn-pick yes ${answers[n]==="yes" ? "selected":""}`}
                onClick={() => pick(n,"yes")}
              >Aceptar</button>
              <button
                className={`btn-pick no ${answers[n]==="no" ? "selected":""}`}
                onClick={() => pick(n,"no")}
              >Declinar</button>
            </div>
          </div>
        ))}
      </div>

      <div className="rsvp-note" style={{marginTop:12}}>
        <label className="sec-text" htmlFor="note">
          Algo para contarle a los novios (mensajito ❤️)
        </label>
        <textarea
          id="note"
          className="textarea"
          value={note}
          onChange={e=>setNote(e.target.value)}
          placeholder="Escribe aquí tu mensaje o preferencias…"
        />
      </div>

      <div className="rsvp-send" style={{marginTop:14}}>
        <button className="btn-confirm" disabled={sending} onClick={submit}>
          {sending ? "Guardando…" : "Confirmar"}
        </button>
      </div>
    </div>
  );
}
