// pages/detalles.jsx
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/router";
import dynamic from "next/dynamic";

import Countdown from "@/components/Countdown";
import RSVPInline from "@/components/RSVPInline";

const QRCode = dynamic(() => import("qrcode.react"), { ssr: false });

export default function DetallesPage() {
  const router = useRouter();
  const { p, n } = router.query;

  const [displayName, setDisplayName] = useState(n ? decodeURIComponent(n) : "");
  const [seats, setSeats] = useState(1);
  const [showQR, setShowQR] = useState(false); // se muestra solo al confirmar

  useEffect(() => {
    async function load() {
      try {
        if (!p) return;
        const r = await fetch(`/api/party?token=${encodeURIComponent(p)}`);
        const j = await r.json();
        if (j?.ok && j.party) {
          const m = Array.isArray(j.party.members) ? j.party.members.filter(Boolean).length : 1;
          setSeats(m > 0 ? m : 1);
          if (!n && j.party.displayName) setDisplayName(j.party.displayName);
        }
      } catch {}
    }
    load();
  }, [p, n]);

  const rsvpLink = useMemo(() => {
    const q = new URLSearchParams();
    if (p) q.set("p", p);
    if (n) q.set("n", n);
    if (typeof window !== "undefined") {
      return `${window.location.origin}/rsvp?${q.toString()}`;
    }
    return "";
  }, [p, n]);

  // mini-calendario (mes simbólico)
  const days = ["D","L","M","M","J","V","S"];
  const decGrid = Array.from({length:31},(_,i)=>i+1);

  return (
    <main className="invite-wrap">
      {/* HERO A */}
      <section className="section">
        <div className="hero-photo reveal">
          {/* Dummy hero — pon tu foto en /public/img/hero.jpg */}
          <img src="/img/hero.jpg" alt="Marielos & Guillermo" />
          <div className="hero-overlay" />
          <div className="hero-center">
            <div className="hero-sub h-font">NUESTRA BODA</div>
            <h1 className="hero-title h-font">Marielos &amp; Guillermo</h1>
          </div>
          <div className="hero-chev"><span /></div>
        </div>
      </section>

      {/* PADRES */}
      <section className="section narrow parents reveal">
        <h2 className="sec-title">Nuestros Padres</h2>
        <div className="parents-grid">
          <div className="card" style={{background:"linear-gradient(180deg, var(--ivory), #fff)"}}>
            <div className="parents-title h-font">Padres de la Novia</div>
            <ul className="parents-list">
              <li>✝ Edwin Baños</li>
              <li>María Eugenia Ortiz</li>
            </ul>
          </div>
          <div className="card" style={{background:"linear-gradient(180deg, var(--ivory), #fff)"}}>
            <div className="parents-title h-font">Padres del Novio</div>
            <ul className="parents-list">
              <li>B. Vinicio Cotto</li>
              <li>R. Marilú Mux</li>
            </ul>
          </div>
        </div>
      </section>

      {/* COUNTDOWN + CALENDARIO */}
      <section className="section narrow reveal">
        <h2 className="sec-title">Cuenta regresiva</h2>
        <div className="countdown-wrap">
          <Countdown targetISO="2025-12-27T16:00:00-06:00" />
        </div>

        <div className="calendar" aria-label="Diciembre 2025">
          <div className="month h-font">Diciembre 2025</div>
          <div className="grid" style={{marginTop:8}}>
            {days.map(d => <div key={d} className="day">{d}</div>)}
            {decGrid.map(d => (
              <div key={d} className={`num ${d===27 ? "hl" : ""}`}>{d}</div>
            ))}
          </div>
        </div>
      </section>

      {/* CEREMONIA + RECEPCIÓN (sin título superior) */}
      <section className="section narrow reveal">
        <div className="places-grid">
          <div className="place">
            <img className="place-icon" src="/img/icons/ceremonia.png" alt="Ceremonia" />
            <div>
              <div className="place-title">Ceremonia</div>
              <div className="place-time">4:00 PM</div>
              <div className="place-name">San José Catedral La Antigua Guatemala</div>
              <a className="link-gold" rel="noreferrer" target="_blank"
                 href="https://maps.app.goo.gl/bqNP5wttNgiLvKL18">
                Ver en Google Maps
              </a>
            </div>
          </div>

          <div className="place">
            <img className="place-icon" src="/img/icons/recepcion.png" alt="Recepción" />
            <div>
              <div className="place-title">Recepción</div>
              <div className="place-time">5:30 PM</div>
              <div className="place-name">Hotel Soleil La Antigua</div>
              <a className="link-gold" rel="noreferrer" target="_blank"
                 href="https://maps.app.goo.gl/QXUBcS3RtBeH7Xp4A">
                Ver en Google Maps
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* INFO: Dress, Adultos, Lluvia de sobres */}
      <section className="section narrow reveal">
        <div className="info-grid">
          <div className="info-card">
            <h3 className="sec-title">Código de vestimenta</h3>
            <p className="sec-text">
              <b>Mujeres:</b> Vestidos largos o midi elegantes, chal o abrigo ligero por el clima de Antigua.
              Tacón cómodo (block heel) por calles empedradas. Tonos neutros o pastel.
            </p>
            <p className="sec-text">
              <b>Caballeros:</b> Traje formal oscuro o tonos tierra. Zapatos de vestir aptos para jardín.
              Abrigo ligero para la noche.
            </p>
          </div>

          <div className="info-card">
            <h3 className="sec-title">Reservado para adultos</h3>
            <p className="sec-text">
              Desde el respeto y el cariño, este evento será exclusivo para adultos.
              ¡Gracias por comprender!
            </p>
          </div>

          <div className="info-card">
            <h3 className="sec-title">Lluvia de sobres</h3>
            <p className="sec-text">
              Tu presencia es nuestro mejor regalo. Si deseas tener un detalle,
              agradecemos tu cariño en forma de lluvia de sobres. ¡Gracias por ser parte
              de este día tan especial!
            </p>
          </div>
        </div>
      </section>

      {/* RSVP INLINE */}
      <section className="section narrow reveal">
        <h2 className="sec-title">Confirma tu asistencia</h2>
        <div className="sec-text" style={{marginBottom:10}}>
          Invitación para <b>{displayName || "Invitado/a"}</b> — lugares reservados: <b>{seats}</b>
        </div>

        <RSVPInline
          token={p}
          fallbackName={displayName}
          onConfirmed={() => setShowQR(true)}
        />
      </section>

      {/* QR — aparece tras confirmar */}
      {showQR && (
        <section className="section narrow reveal">
          <div className="qr-box">
            <h3 className="sec-title">Tu QR de invitación</h3>
            <p className="sec-text">Preséntalo en el ingreso o úsalo para abrir tu RSVP.</p>
            {rsvpLink && <QRCode value={rsvpLink} size={160} includeMargin />}
            <div className="sec-text" style={{marginTop:6}}>{displayName || "Invitado/a"}</div>
          </div>
        </section>
      )}

      {/* CALENDAR BUTTON (sutil dorado) */}
      <section className="section narrow text-center reveal">
        <a
          className="btn-gold"
          target="_blank" rel="noreferrer"
          href={(() => {
            const title = "Boda de Marielos & Guillermo";
            const start = "2025-12-27T16:00:00-06:00";
            const end   = "2025-12-28T00:00:00-06:00";
            const details = "¡Te esperamos para celebrar con nosotros! 💍";
            const location = "San José Catedral y Hotel Soleil La Antigua";
            const params = new URLSearchParams({
              action:"TEMPLATE",
              text:title,
              dates:`${start.replace(/[-:]/g,"").replace(".000","").replace(/Z$/,"")}/${end.replace(/[-:]/g,"").replace(".000","").replace(/Z$/,"")}`,
              details, location
            });
            return `https://calendar.google.com/calendar/render?${params.toString()}`;
          })()}
        >
          Añadir al calendario
        </a>
      </section>

      {/* FOOTER WHATSAPP */}
      <footer className="section narrow text-center">
        <p className="sec-text">
          ¿Dudas? Escríbenos por&nbsp;
          <a className="link-gold" href="https://wa.me/50248075868" target="_blank" rel="noreferrer">
            WhatsApp
          </a>
        </p>
      </footer>
    </main>
  );

  
}
