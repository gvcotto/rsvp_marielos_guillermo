export default async function handler(req, res) {
  try {
    const { token } = req.query;
    const base = process.env.GSHEET_GET_URL; // https://script.google.com/macros/s/XXX/exec
    const r = await fetch(`${base}?action=party&token=${encodeURIComponent(token)}`);
    const data = await r.json();
    res.status(200).json(data);
  } catch (e) {
    res.status(500).json({ ok:false, error:String(e) });
  }
}
