// pages/rsvp.jsx
import { useRouter } from 'next/router';
import { useState, useEffect } from 'react';

export default function RSVP(){
  const router = useRouter();
  const { p, n } = router.query;

  const [displayName, setDisplayName] = useState('');
  const [answer, setAnswer] = useState('');        // modo invitación individual
  const [guests, setGuests] = useState(0);         // modo invitación individual
  const [note, setNote] = useState('');

  // Party (grupo)
  const [party, setParty] = useState(null);
  const [memberAnswers, setMemberAnswers] = useState([]); // [{name, answer:'Sí'|'No'|''}]
  const [extraNames, setExtraNames] = useState([]);       // nombres de +extras

  const [sent, setSent]   = useState(false);
  const [error, setError] = useState('');

  useEffect(()=>{
    async function init(){
      if(p){
        try{
          const r = await fetch(`/api/party?token=${encodeURIComponent(p)}`);
          const j = await r.json();
          if(j?.ok && j.party){
            setParty(j.party);
            setDisplayName(j.party.displayName || (n?decodeURIComponent(n):''));
            setMemberAnswers((j.party.members||[]).map(m=>({name:m,answer:''})));
            setExtraNames(Array.from({length: j.party.allowedExtra||0}, ()=>'')); // campos para +extras
            return;
          }
        }catch{/* ignore */}
      }
      // fallback: invitación individual
      if(n) setDisplayName(decodeURIComponent(n));
    }
    init();
  },[p,n]);

  const setAnswerFor = (idx,val)=>
    setMemberAnswers(prev=> prev.map((m,i)=> i===idx?{...m,answer:val}:m));

  const sendForm = async (e)=>{
    e.preventDefault();
    setError('');
    try{
      let payload;
      if(party){
        const confirmedCount = memberAnswers.filter(m=>m.answer==='Sí').length;
        const extrasFilled   = extraNames.filter(x=> (x||'').trim().length>0);
        payload = {
          token: p||null,
          name: displayName,
          answer: 'grupo',
          guests: confirmedCount + extrasFilled.length,
          note: JSON.stringify({ members: memberAnswers, extras: extrasFilled, comment: note }),
          receivedAt: new Date().toISOString(),
        };
      }else{
        payload = {
          token:p||null,
          name: displayName,
          answer,
          guests,
          note,
          receivedAt:new Date().toISOString()
        };
      }

      const res = await fetch('/api/rsvp',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify(payload)
      });
      if(!res.ok){
        const t = await res.text();
        throw new Error(t||'Error en el envío');
      }
      setSent(true);
    }catch(err){
      setError(err.message);
    }
  };

  if(sent){
    return (
      <div className="min-h-screen flex items-center justify-center bg-rose-50 p-6">
        <div className="bg-white shadow-xl rounded-xl p-8 text-center">
          <p className="text-lg">¡Gracias por confirmar, {displayName||'invitado/a'}! 💐</p>
        </div>
      </div>
    );
  }

  // Para party: todos marcados Sí/No
  const allMarked = party ? memberAnswers.every(m => m.answer === 'Sí' || m.answer === 'No') : true;

  return (
    <div className="min-h-screen flex items-center justify-center bg-rose-50 p-6">
      <form onSubmit={sendForm} className="bg-white shadow-xl rounded-xl p-8 space-y-4 w-full max-w-md">
        <h1 className="h-font text-2xl font-semibold text-center" style={{color:'var(--euca-green)'}}>Confirma tu asistencia</h1>

        <div>
          <label className="block text-sm font-medium">Nombre del grupo</label>
          <input
            className="border p-2 w-full rounded mt-1"
            value={displayName}
            readOnly={!!party}
            onChange={e=>setDisplayName(e.target.value)}
            required
          />
        </div>

        {/* ======== PARTY (grupo) ======== */}
        {party ? (
          <div className="space-y-5">
            {/* Lista de miembros con Accept/Decline */}
            <div>
              <label className="block text-sm font-medium mb-2">Selecciona por persona</label>
              <div className="space-y-3">
                {memberAnswers.map((m, idx) => {
                  const isYes = m.answer === "Sí";
                  const isNo  = m.answer === "No";
                  return (
                    <div key={idx} className="flex items-center justify-between gap-4">
                      <span className="text-base">{m.name}</span>
                      <div className="flex gap-3">
                        <button
                          type="button"
                          onClick={() => setAnswerFor(idx, "Sí")}
                          className={`px-5 py-2 rounded border transition ${isYes ? "text-white" : "bg-white"}`}
                          style={isYes ? { backgroundColor: "var(--euca-green)"} : {}}
                          aria-pressed={isYes}
                        >
                          Accept
                        </button>
                        <button
                          type="button"
                          onClick={() => setAnswerFor(idx, "No")}
                          className={`px-5 py-2 rounded border transition ${isNo ? "bg-gray-300" : "bg-white"}`}
                          aria-pressed={isNo}
                        >
                          Decline
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Extras con nombre si aplica */}
            {extraNames.length>0 && (
              <div>
                <label className="block text-sm font-medium">Acompañantes extra (nombres):</label>
                {extraNames.map((val,i)=>(
                  <input
                    key={i}
                    className="border p-2 w-full rounded mt-2"
                    placeholder={`Nombre del extra ${i+1}`}
                    value={val}
                    onChange={e=>{
                      const v=e.target.value;
                      setExtraNames(prev=> prev.map((x,idx)=> idx===i?v:x));
                    }}
                  />
                ))}
                <p className="text-xs text-gray-500 mt-1">Puedes dejar en blanco si no usarás el extra.</p>
              </div>
            )}

            {/* Nota */}
            <div>
              <label className="block text-sm font-medium">Nota / Preferencias</label>
              <textarea
                className="border p-2 w-full rounded mt-1"
                rows={3}
                value={note}
                onChange={e=>setNote(e.target.value)}
              />
            </div>

            {/* Botón deshabilitado hasta que todos estén marcados */}
            <button
              type="submit"
              className={`w-full py-2 rounded text-white transition ${allMarked ? "" : "opacity-50 cursor-not-allowed"}`}
              style={{backgroundColor:'var(--euca-green)'}}
              disabled={!allMarked}
              title={allMarked ? "Enviar" : "Selecciona Accept/Decline para cada persona"}
            >
              {allMarked ? "Enviar" : "Continuar"}
            </button>
          </div>
        ) : (
        /* ======== INVITACIÓN INDIVIDUAL ======== */
          <div>
            <label className="block text-sm font-medium">¿Asistirás?</label>
            <div className="mt-2 flex gap-3">
              <button
                type="button"
                onClick={()=>setAnswer('Sí')}
                className={`px-4 py-2 rounded ${answer==='Sí'?'text-white':'border'}`}
                style={answer==='Sí'?{backgroundColor:'var(--euca-green)'}:{}}
              >
                Sí
              </button>
              <button
                type="button"
                onClick={()=>setAnswer('No')}
                className={`px-4 py-2 rounded ${answer==='No'?'bg-gray-300':'border'}`}
              >
                No
              </button>
            </div>

            <div className="mt-3">
              <label className="block text-sm font-medium">Acompañantes (además de ti)</label>
              <input
                type="number"
                min="0"
                className="border p-2 w-24 rounded mt-1"
                value={guests}
                onChange={e=>setGuests(Number(e.target.value)||0)}
              />
            </div>

            <div className="mt-3">
              <label className="block text-sm font-medium">Nota / Preferencias</label>
              <textarea
                className="border p-2 w-full rounded mt-1"
                rows={3}
                value={note}
                onChange={e=>setNote(e.target.value)}
              />
            </div>

            {/* botón para el modo individual */}
            <button type="submit" className="w-full py-2 rounded text-white" style={{backgroundColor:'var(--euca-green)'}}>
              Enviar
            </button>
          </div>
        )}

        {/* Errores */}
        {error && <p className="text-red-600 text-sm">{error}</p>}
      </form>
    </div>
  );
}
