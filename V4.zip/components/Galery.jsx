// components/Gallery.jsx
export default function Gallery() {
  const imgs = ["/img/hero1.jpg", "/img/hero2.jpg", "/img/hero3.jpg"];
  return (
    <div className="gal-grid">
      {imgs.map((src, i) => (
        <img key={i} src={src} alt={`img-${i}`} className="gal-img" />
      ))}
    </div>
  );
}
