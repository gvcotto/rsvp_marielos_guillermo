﻿import { useEffect, useMemo, useState } from "react";

const ANSWER_YES_VALUE = "yes";
const ANSWER_NO_VALUE = "no";
const ANSWER_YES_LABEL = "Sí";
const ANSWER_NO_LABEL = "No";

export default function RSVPInline({
  token,
  fallbackName,
  onConfirmed = () => {},
}) {
  const [members, setMembers] = useState([]);
  const [answers, setAnswers] = useState({});
  const [note, setNote] = useState("");
  const [sending, setSending] = useState(false);
  const [ok, setOk] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;

    async function loadMembers() {
      if (!token) {
        const name = (fallbackName || "Invitado/a").trim();
        if (!cancelled) {
          setMembers([name]);
          setAnswers((prev) => ({ ...prev, [name]: prev[name] || "" }));
        }
        return;
      }

      try {
        const response = await fetch(
          `/api/party?token=${encodeURIComponent(token)}`
        );
        const json = await response.json();
        if (cancelled) return;

        if (json?.ok && json.party) {
          const cleanMembers = Array.isArray(json.party.members)
            ? json.party.members.filter(Boolean)
            : [];

          const fallbackDisplayName =
            json.party.displayName?.trim() || fallbackName || "Invitado/a";

          const list = cleanMembers.length ? cleanMembers : [fallbackDisplayName];

          setMembers(list);
          setAnswers((prev) => {
            const next = { ...prev };
            list.forEach((name) => {
              next[name] = prev[name] || "";
            });
            return next;
          });
        } else {
          throw new Error("Respuesta inválida del servidor.");
        }
      } catch (err) {
        console.error("No se pudo cargar el grupo", err);
        if (!cancelled) {
          setError(
            "No pudimos cargar la lista de invitados. Intenta nuevamente en unos minutos."
          );
        }
      }
    }

    loadMembers();
    return () => {
      cancelled = true;
    };
  }, [token, fallbackName]);

  const allSelected = useMemo(() => {
    if (!members.length) return false;
    return members.every((name) => Boolean(answers[name]));
  }, [members, answers]);

  const setAnswer = (name, value) => {
    setAnswers((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async () => {
    if (!allSelected) {
      setError("Selecciona una opción para cada invitado.");
      return;
    }

    setSending(true);
    setError("");

    try {
      const now = new Date().toISOString();
      const cleanedNote = note.trim();

      const rows = members.map((name) => ({
        token: token || null,
        name,
        answer: answers[name],
        note: cleanedNote,
        receivedAt: now,
      }));

      const summary = {
        type: members.length > 1 ? "grupo" : "individual",
        submittedAt: now,
        note: cleanedNote || null,
        members: members.map((name) => ({ name, answer: answers[name] })),
      };

      const response = await fetch("/api/rsvp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rows }),
      });

      if (!response.ok) {
        const text = await response.text();
        throw new Error(text || "No pudimos registrar la confirmación.");
      }

      setOk(true);
      onConfirmed(summary);
    } catch (err) {
      setError(err.message);
    } finally {
      setSending(false);
    }
  };

  if (ok) {
    return (
      <div className="card" style={{ textAlign: "center" }}>
        <div className="sec-title">¡Gracias por confirmar!</div>
        <div className="sec-text">
          Registramos tu respuesta correctamente. Te esperamos.
        </div>
      </div>
    );
  }

  return (
    <div className="rsvp-card gold-card">
      <div className="rsvp-header">
        <div className="sec-text">
          Grupo: <b>{fallbackName || "Invitado/a"}</b>
        </div>
      </div>

      <div className="rsvp-members">
        {members.map((name) => {
          const answer = answers[name];
          return (
            <div key={name} className="member-row">
              <div className="member-name">{name}</div>
              <div className="btns">
                <button
                  type="button"
                  className={`btn-accept ${answer === ANSWER_YES_VALUE ? "active" : ""}`}
                  onClick={() => setAnswer(name, ANSWER_YES_VALUE)}
                  aria-pressed={answer === ANSWER_YES_VALUE}
                >
                  {ANSWER_YES_LABEL}
                </button>
                <button
                  type="button"
                  className={`btn-decline ${answer === ANSWER_NO_VALUE ? "active" : ""}`}
                  onClick={() => setAnswer(name, ANSWER_NO_VALUE)}
                  aria-pressed={answer === ANSWER_NO_VALUE}
                >
                  {ANSWER_NO_LABEL}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <div className="rsvp-note" style={{ marginTop: 16 }}>
        <label className="sec-text" htmlFor="rsvp-note">
          Mensaje para los novios (opcional)
        </label>
        <textarea
          id="rsvp-note"
          className="textarea"
          value={note}
          onChange={(event) => setNote(event.target.value)}
          placeholder="Cuéntanos si tienes alguna preferencia o mensaje especial."
        />
      </div>

      <div className="rsvp-send" style={{ marginTop: 18 }}>
        <button
          type="button"
          className="btn-confirm"
          onClick={handleSubmit}
          disabled={!allSelected || sending}
        >
          {sending ? "Guardando..." : "Confirmar asistencia"}
        </button>
      </div>

      {error && (
        <div className="notice" role="alert">
          {error}
        </div>
      )}
    </div>
  );
}
