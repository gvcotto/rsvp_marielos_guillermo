﻿import Image from "next/image";
import jsPDF from "jspdf";
import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/router";
import dynamic from "next/dynamic";

import CalendarBadge from "@/components/CalendarBadge";
import Countdown from "@/components/Countdown";
import Reveal from "@/components/Reveal";
import RSVPInline from "@/components/RSVPInline";

const QRCodeCanvas = dynamic(
  () =>
    import("qrcode.react").then(
      (mod) => mod.QRCodeCanvas ?? mod.default ?? mod
    ),
  { ssr: false }
);

const WEDDING_START = "2025-12-27T16:00:00-06:00";
const WEDDING_END = "2025-12-28T00:00:00-06:00";
const EVENT_ID = "boda-marielos-guillermo-2025";
const ANSWER_YES = "Sí";

const encodePayload = (data) => {
  if (typeof window === "undefined") return "";
  const raw = JSON.stringify(data);
  return window.btoa(unescape(encodeURIComponent(raw)));
};

export default function DetallesPage() {
  const router = useRouter();
  const { p, n } = router.query;

  const [displayName, setDisplayName] = useState(
    n ? decodeURIComponent(n) : ""
  );
  const [seats, setSeats] = useState(1);
  const [showQR, setShowQR] = useState(false);
  const [confirmationSummary, setConfirmationSummary] = useState(null);

  const qrWrapperRef = useRef(null);

  useEffect(() => {
    async function load() {
      if (!p) return;

      try {
        const response = await fetch(
          `/api/party?token=${encodeURIComponent(p)}`
        );
        const json = await response.json();

        if (json?.ok && json.party) {
          const members = Array.isArray(json.party.members)
            ? json.party.members.filter(Boolean).length
            : 1;

          setSeats(members > 0 ? members : 1);
          if (!n && json.party.displayName) {
            setDisplayName(json.party.displayName);
          }
        }
      } catch (err) {
        console.error("No se pudo cargar el grupo", err);
      }
    }

    load();
  }, [p, n]);

  const entryPayload = useMemo(() => {
    const base = {
      type: "wedding-entry",
      event: EVENT_ID,
      name: displayName || "Invitado/a",
      seats,
      token: p || null,
    };

    if (confirmationSummary) {
      base.summary = confirmationSummary;
    }

    return encodePayload(base);
  }, [displayName, seats, p, confirmationSummary]);

  const calendarUrl = useMemo(() => {
    const format = (value) =>
      value.replace(/[-:]/g, "").replace(".000", "").replace(/Z$/, "");
    const query = new URLSearchParams({
      action: "TEMPLATE",
      text: "Boda de Marielos y Guillermo",
      dates: `${format(WEDDING_START)}/${format(WEDDING_END)}`,
      details: "Te esperamos para celebrar con nosotros.",
      location: "San José Catedral y Hotel Soleil La Antigua",
    });
    return `https://calendar.google.com/calendar/render?${query.toString()}`;
  }, []);

  const handleDownloadPdf = () => {
    const wrapper = qrWrapperRef.current;
    const canvas = wrapper?.querySelector("canvas");
    if (!canvas) return;

    const dataUrl = canvas.toDataURL("image/png");

    const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a6" });
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const margin = 10;

    // Cabecera en tono dorado
    pdf.setFillColor(252, 224, 157);
    pdf.rect(0, 0, pageWidth, 24, "F");

    pdf.setTextColor(133, 95, 13);
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(14);
    pdf.text("Boda Marielos & Guillermo", margin, 16);

    pdf.setFontSize(18);
    pdf.text("MG", pageWidth - margin, 17, { align: "right" });

    pdf.setDrawColor(211, 176, 102);
    pdf.roundedRect(margin, 28, pageWidth - margin * 2, pageHeight - 38, 6, 6);

    const qrSize = Math.min(pageWidth - 40, pageHeight / 2.2);
    const qrX = (pageWidth - qrSize) / 2;
    const qrY = 34;

    pdf.addImage(dataUrl, "PNG", qrX, qrY, qrSize, qrSize);

    let cursorY = qrY + qrSize + 10;
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(12);
    pdf.text(displayName || "Invitado/a", pageWidth / 2, cursorY, {
      align: "center",
    });

    cursorY += 6;
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(10);
    pdf.text(
      `Lugares reservados: ${seats}`,
      pageWidth / 2,
      cursorY,
      { align: "center" }
    );

    cursorY += 8;

    if (confirmationSummary?.members?.length) {
      pdf.setFont("helvetica", "bold");
      pdf.text("Detalle de confirmación:", margin + 2, cursorY);
      cursorY += 6;

      pdf.setFont("helvetica", "normal");
      confirmationSummary.members.forEach((member) => {
        const normalizedAnswer = (member.answer || "").toString().trim().toLowerCase();
        const isYes = AFFIRMATIVE_VALUES.has(normalizedAnswer);
        const readableAnswer = isYes ? "Sí" : normalizedAnswer ? normalizedAnswer === "no" ? "No" : member.answer : "No";
        const symbol = isYes ? "✔" : "✘";
        pdf.text(
          `${symbol} ${member.name} - ${member.answer}`,
          margin + 4,
          cursorY
        );
        cursorY += 5;
      });
    }

    if (confirmationSummary?.note) {
      cursorY += 4;
      pdf.setFont("helvetica", "bold");
      pdf.text("Mensaje:", margin + 2, cursorY);
      cursorY += 5;
      pdf.setFont("helvetica", "normal");
      const split = pdf.splitTextToSize(
        confirmationSummary.note,
        pageWidth - margin * 2 - 4
      );
      pdf.text(split, margin + 4, cursorY);
    }

    pdf.save("invitacion-qr.pdf");
  };

  return (
    <main className="invite-wrap text-ink">
      <section className="section">
        <div className="relative overflow-hidden rounded-3xl bg-black/40 shadow-soft">
          <div className="relative h-[68vh] min-h-[420px] w-full">
            <Image
              src="/photos/hero1.jpg"
              alt="Marielos y Guillermo"
              fill
              priority
              className="object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/10 via-black/60 to-black/25" />

            <div className="absolute inset-0 flex flex-col items-center justify-center px-6 text-center">
              <p className="h-font hero-sub hero-sub-white">Nuestra Boda</p>
              <h1 className="h-font hero-names hero-names-outline text-4xl leading-tight md:text-6xl lg:text-7xl" data-text="Marielos &amp; Guillermo">
                Marielos &amp; Guillermo
              </h1>
              <p className="hero-date mt-4 max-w-xl text-base md:text-lg">
                27 de diciembre de 2025 - La Antigua Guatemala
              </p>
            </div>

            <a
              href="#rsvp"
              className="absolute bottom-8 left-1/2 flex h-12 w-12 -translate-x-1/2 items-center justify-center rounded-full border border-white/40 bg-white/10 text-white transition hover:bg-white/20"
              aria-label="Ir a confirmar asistencia"
            >
              <span className="border-b-2 border-r-2 border-white/90 p-2.5 rotate-45" />
            </a>
          </div>
        </div>
      </section>

      <Reveal className="section narrow">
        <div className="gold-card gold-card--soft text-center space-y-6">
          <p className="body-font text-base text-gray-700">
            Dios nos ha concedido el privilegio de conocernos y amarnos. Con su
            bendición y la de nuestros padres queremos unir nuestras vidas para
            siempre.
          </p>

          <div className="grid gap-8 md:grid-cols-2">
            <div>
              <h3 className="h-font gold-gradient text-lg uppercase tracking-[0.3em]">
                Padres de la novia
              </h3>
              <div className="mt-4 space-y-1 text-base text-gray-700">
                <div>Edwin Baños (+)</div>
                <div>María Eugenia Ortiz</div>
              </div>
            </div>
            <div>
              <h3 className="h-font gold-gradient text-lg uppercase tracking-[0.3em]">
                Padres del novio
              </h3>
              <div className="mt-4 space-y-1 text-base text-gray-700">
                <div>Vinicio Cotto</div>
                <div>Marilú Mux</div>
              </div>
            </div>
          </div>

          <p className="body-font text-base text-gray-700">
            Te invitamos a ser parte de este capítulo tan especial en nuestra historia.
          </p>
        </div>
      </Reveal>

      <Reveal className="section narrow">
        <div className="gold-card gold-card--soft flex flex-col items-center gap-8 lg:flex-row lg:items-center lg:justify-center">
          <div className="gold-card__inner">
            <Countdown targetISO={WEDDING_START} />
          </div>
          <div className="flex flex-col items-center gap-4">
            <CalendarBadge />
            <a
              href={calendarUrl}
              target="_blank"
              rel="noreferrer"
              className="btn-gold"
            >
              Añadir al calendario
            </a>
          </div>
        </div>
      </Reveal>

      <Reveal className="section narrow">
        <div className="grid gap-6 md:grid-cols-2">
          <PlaceCard
            icon="/icons/ceremonia.png"
            title="Ceremonia"
            time="4:00 PM"
            location="San José Catedral, La Antigua Guatemala"
            link="https://maps.app.goo.gl/bqNP5wttNgiLvKL18"
          />
          <PlaceCard
            icon="/icons/recepcion.png"
            title="Recepción"
            time="5:30 PM"
            location="Hotel Soleil La Antigua"
            link="https://maps.app.goo.gl/QXUBcS3RtBeH7Xp4A"
          />
        </div>
      </Reveal>

      <Reveal className="section narrow">
        <div className="grid gap-6 md:grid-cols-3">
          <InfoCard
            title="Código de vestimenta"
            description={[
              "Mujeres: vestidos largos o midi elegantes en tonos neutros o metálicos suaves. Lleva un chal o abrigo ligero.",
              "Caballeros: traje formal en tonos oscuros o tierra y zapatos de vestir cómodos para jardín.",
            ]}
          />
          <InfoCard
            title="Reservado para adultos"
            description={[
              "Desde el cariño y el respeto, esta celebración será exclusiva para adultos.",
              "Agradecemos tu comprensión y cariño.",
            ]}
          />
          <InfoCard
            title="Lluvia de sobres"
            description={[
              "Tu presencia es el mejor regalo para nosotros.",
              "Si deseas hacernos un obsequio, agradeceríamos que sea en forma de sobre. Tendremos un lugar especial disponible durante el evento.",
            ]}
          />
        </div>
      </Reveal>

      <Reveal className="section narrow" id="rsvp">
        <div className="gold-card gold-card--soft">
          <div className="mx-auto flex max-w-xl flex-col items-center text-center">
            <div className="mb-5 flex items-center gap-3">
              <span className="heart-badge">
                <span>
                  <HeartIcon />
                </span>
              </span>
              <h2 className="h-font text-2xl gold-gradient">
                Confirma tu asistencia
              </h2>
            </div>
            <p className="sec-text mb-6">
              Invitación para <b>{displayName || "Invitado/a"}</b>. Lugares
              reservados: <b>{seats}</b>
            </p>
          </div>

          <RSVPInline
            token={p}
            fallbackName={displayName}
            onConfirmed={(summary) => {
              setConfirmationSummary(summary);
              setShowQR(true);
            }}
          />
        </div>
      </Reveal>

      {showQR && (
        <Reveal className="section narrow">
          <div className="gold-card gold-card--soft text-center">
            <h3 className="h-font gold-gradient text-xl">Tu código QR</h3>
            <p className="sec-text mb-6">
              Presenta este código al llegar. El equipo validará tu invitación y asignará tu mesa.
            </p>
            {entryPayload && (
              <div
                ref={qrWrapperRef}
                className="mx-auto w-max rounded-2xl border border-[#d9b97a80] bg-white p-4 shadow-inner"
              >
                <QRCodeCanvas value={entryPayload} size={200} includeMargin level="H" />
              </div>
            )}
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <button type="button" onClick={handleDownloadPdf} className="btn-gold">
                Descargar PDF
              </button>
            </div>
            <p className="sec-text mt-4">{displayName || "Invitado/a"}</p>
          </div>
        </Reveal>
      )}

      <Reveal className="section narrow text-center">
        <p className="sec-text">
          ¿Dudas? Escríbenos por{" "}
          <a
            className="link-gold font-semibold"
            href="https://wa.me/50248075868"
            target="_blank"
            rel="noreferrer"
          >
            WhatsApp
          </a>
        </p>
      </Reveal>
    </main>
  );
}

function PlaceCard({ icon, title, time, location, link }) {
  return (
    <div className="gold-card place-card flex items-start gap-4">
      <div className="flex h-16 w-16 flex-none items-center justify-center rounded-2xl bg-white shadow-inner">
        <Image
          src={icon}
          alt={title}
          width={44}
          height={44}
          className="object-contain"
        />
      </div>
      <div className="space-y-1 text-left">
        <h3 className="h-font gold-gradient text-xl">{title}</h3>
        <p className="text-sm font-semibold text-[var(--gold-text,#a57b2c)]">
          {time}
        </p>
        <p className="text-gray-700">{location}</p>
        <a
          href={link}
          target="_blank"
          rel="noreferrer"
          className="link-gold inline-flex items-center gap-1 text-sm font-semibold"
        >
          Ver en Google Maps
        </a>
      </div>
    </div>
  );
}

function InfoCard({ title, description }) {
  return (
    <div className="gold-card info-card">
      <h3 className="h-font gold-gradient text-xl info-card__title">{title}</h3>
      <div className="info-card__body">
        {description.map((paragraph, index) => (
          <p key={index} className="info-card__text">
            {paragraph}
          </p>
        ))}
      </div>
    </div>
  );
}

function HeartIcon() {
  return (
    <svg
      width="20"
      height="18"
      viewBox="0 0 24 22"
      fill="currentColor"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <path d="M11.76 21.35L10.1 19.82C4.44 14.67 1 11.55 1 7.64 1 4.52 3.49 2 6.54 2 8.36 2 10.09 2.87 11.1 4.24 12.11 2.87 13.84 2 15.66 2 18.71 2 21.2 4.52 21.2 7.64 21.2 11.55 17.76 14.67 12.1 19.82L11.76 21.35Z" />
    </svg>
  );
}


















