﻿import { useRouter } from "next/router";
import { useEffect, useMemo, useState } from "react";

const ANSWER_YES_VALUE = "SA-";
const ANSWER_NO_VALUE = "No";

export default function RSVP() {
  const router = useRouter();
  const { p, n } = router.query;

  const [displayName, setDisplayName] = useState("");
  const [answer, setAnswer] = useState("");
  const [guests, setGuests] = useState(0);
  const [note, setNote] = useState("");

  const [party, setParty] = useState(null);
  const [memberAnswers, setMemberAnswers] = useState([]);
  const [extraNames, setExtraNames] = useState([]);

  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const invitedName = n ? decodeURIComponent(n) : "";
    if (invitedName && !displayName) {
      setDisplayName(invitedName);
    }

    async function init() {
      if (!p) return;
      try {
        const response = await fetch(`/api/party?token=${encodeURIComponent(p)}`);
        const json = await response.json();

        if (json?.ok && json.party) {
          const members = Array.isArray(json.party.members)
            ? json.party.members.filter(Boolean)
            : [];

          setParty(json.party);
          setDisplayName(json.party.displayName || invitedName || "Invitado/a");
          setMemberAnswers(members.map((name) => ({ name, answer: "" })));
          setExtraNames(
            Array.from({ length: json.party.allowedExtra || 0 }, () => "")
          );
        }
      } catch (err) {
        console.error("No se pudo cargar el grupo", err);
      }
    }

    init();
  }, [p, n, displayName]);

  const allMarked = useMemo(() => {
    if (!party) return true;
    return memberAnswers.every(
      (member) => member.answer === ANSWER_YES_VALUE || member.answer === ANSWER_NO_VALUE
    );
  }, [party, memberAnswers]);

  const setAnswerFor = (index, value) => {
    setMemberAnswers((prev) =>
      prev.map((member, i) => (i === index ? { ...member, answer: value } : member))
    );
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");

    if (!displayName.trim()) {
      setError("Por favor escribe el nombre del invitado o grupo.");
      return;
    }

    if (party && !allMarked) {
      setError("Selecciona una respuesta para cada persona invitada.");
      return;
    }

    if (!party && !answer) {
      setError("Indica si podrás acompañarnos.");
      return;
    }

    setSubmitting(true);

    try {
      const now = new Date().toISOString();
      const trimmedNote = note.trim();
      let payload;

      if (party) {
        const extrasFilled = extraNames
          .map((name) => name.trim())
          .filter((name) => name.length > 0);

        const confirmedCount = memberAnswers.filter(
          (member) => member.answer === ANSWER_YES_VALUE
        ).length;

        payload = {
          token: p || null,
          name: displayName.trim(),
          answer: "grupo",
          guests: confirmedCount + extrasFilled.length,
          note: JSON.stringify({
            members: memberAnswers,
            extras: extrasFilled,
            comment: trimmedNote || null,
          }),
          receivedAt: now,
        };
      } else {
        payload = {
          token: p || null,
          name: displayName.trim(),
          answer,
          guests,
          note: trimmedNote,
          receivedAt: now,
        };
      }

      const response = await fetch("/api/rsvp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const text = await response.text();
        throw new Error(text || "No pudimos registrar tu respuesta.");
      }

      setSent(true);
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  if (sent) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-rose-50 p-6">
        <div className="bg-white shadow-xl rounded-xl p-8 text-center space-y-2">
          <p className="text-lg">
            ¡Gracias por confirmar, {displayName || "invitado/a"}!
          </p>
          <p className="text-sm text-gray-600">
            Recibimos tu respuesta y pronto te enviaremos más detalles.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-rose-50 p-6">
      <form
        onSubmit={handleSubmit}
        className="bg-white shadow-xl rounded-xl p-8 space-y-5 w-full max-w-md"
      >
        <h1
          className="h-font text-2xl font-semibold text-center gold-gradient"
          style={{ WebkitTextFillColor: "transparent" }}
        >
          Confirma tu asistencia
        </h1>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Nombre del invitado o grupo
          </label>
          <input
            className="border border-gray-300 p-2 w-full rounded mt-1 focus:outline-none focus:ring-2 focus:ring-rose-200"
            value={displayName}
            readOnly={Boolean(party)}
            onChange={(event) => setDisplayName(event.target.value)}
            required
          />
        </div>

        {party ? (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Selecciona la respuesta de cada persona
              </label>
              <div className="space-y-3">
                {memberAnswers.map((member, index) => {
                  const isYes = member.answer === ANSWER_YES_VALUE;
                  const isNo = member.answer === ANSWER_NO_VALUE;

                  return (
                    <div
                      key={member.name || index}
                      className="flex items-center justify-between gap-4"
                    >
                      <span className="text-base text-gray-900">
                        {member.name}
                      </span>
                      <div className="flex gap-3">
                        <button
                          type="button"
                          onClick={() => setAnswerFor(index, ANSWER_YES_VALUE)}
                          className={`px-5 py-2 rounded border transition ${
                            isYes
                              ? "bg-emerald-600 border-emerald-600 text-white shadow"
                              : "bg-white border-gray-300 text-gray-700"
                          }`}
                          aria-pressed={isYes}
                        >
                          Sí
                        </button>
                        <button
                          type="button"
                          onClick={() => setAnswerFor(index, ANSWER_NO_VALUE)}
                          className={`px-5 py-2 rounded border transition ${
                            isNo
                              ? "bg-gray-200 border-gray-300 text-gray-800"
                              : "bg-white border-gray-300 text-gray-700"
                          }`}
                          aria-pressed={isNo}
                        >
                          No
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {extraNames.length > 0 && (
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Acompañantes extra (opcional)
                </label>
                {extraNames.map((value, index) => (
                  <input
                    key={`extra-${index}`}
                    className="border border-gray-300 p-2 w-full rounded mt-2 focus:outline-none focus:ring-2 focus:ring-rose-200"
                    placeholder={`Nombre del acompañante ${index + 1}`}
                    value={value}
                    onChange={(event) => {
                      const nextValue = event.target.value;
                      setExtraNames((prev) =>
                        prev.map((name, i) => (i === index ? nextValue : name))
                      );
                    }}
                  />
                ))}
                <p className="text-xs text-gray-500 mt-2">
                  Déjalo en blanco si no utilizarás los lugares extra.
                </p>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Nota o preferencias
              </label>
              <textarea
                className="border border-gray-300 p-2 w-full rounded mt-1 focus:outline-none focus:ring-2 focus:ring-rose-200"
                rows={3}
                value={note}
                onChange={(event) => setNote(event.target.value)}
              />
            </div>

            <button
              type="submit"
              className={`w-full py-2 rounded text-white transition ${
                allMarked && !submitting
                  ? "bg-emerald-600 hover:bg-emerald-700"
                  : "bg-emerald-600 opacity-60 cursor-not-allowed"
              }`}
              disabled={!allMarked || submitting}
            >
              {submitting ? "Enviando..." : "Confirmar asistencia"}
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                ¿Podrás asistir?
              </label>
              <div className="mt-2 flex gap-3">
                <button
                  type="button"
                  onClick={() => setAnswer(ANSWER_YES_VALUE)}
                  className={`px-4 py-2 rounded border transition ${
                    answer === ANSWER_YES_VALUE
                      ? "bg-emerald-600 border-emerald-600 text-white shadow"
                      : "bg-white border-gray-300 text-gray-700"
                  }`}
                  aria-pressed={answer === ANSWER_YES_VALUE}
                >
                  Sí
                </button>
                <button
                  type="button"
                  onClick={() => setAnswer(ANSWER_NO_VALUE)}
                  className={`px-4 py-2 rounded border transition ${
                    answer === ANSWER_NO_VALUE
                      ? "bg-gray-200 border-gray-300 text-gray-800"
                      : "bg-white border-gray-300 text-gray-700"
                  }`}
                  aria-pressed={answer === ANSWER_NO_VALUE}
                >
                  No
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Acompañantes adicionales (además de ti)
              </label>
              <input
                type="number"
                min="0"
                className="border border-gray-300 p-2 w-28 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-rose-200"
                value={guests}
                onChange={(event) => setGuests(Number(event.target.value) || 0)}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Nota o preferencias
              </label>
              <textarea
                className="border border-gray-300 p-2 w-full rounded mt-1 focus:outline-none focus:ring-2 focus:ring-rose-200"
                rows={3}
                value={note}
                onChange={(event) => setNote(event.target.value)}
              />
            </div>

            <button
              type="submit"
              className={`w-full py-2 rounded text-white transition ${
                answer && !submitting
                  ? "bg-emerald-600 hover:bg-emerald-700"
                  : "bg-emerald-600 opacity-60 cursor-not-allowed"
              }`}
              disabled={!answer || submitting}
            >
              {submitting ? "Enviando..." : "Confirmar asistencia"}
            </button>
          </div>
        )}

        {error && <p className="text-red-600 text-sm">{error}</p>}
      </form>
    </div>
  );
}
